package tw.teddysoft.gof.Observer.ans;

public enum Status {
	PENDING, OK, WARRING, CRITICAL;
}
