package tw.teddysoft.gof.Observer.exercise;

public enum Status {
	PENDING, OK, WARRING, CRITICAL;
}
