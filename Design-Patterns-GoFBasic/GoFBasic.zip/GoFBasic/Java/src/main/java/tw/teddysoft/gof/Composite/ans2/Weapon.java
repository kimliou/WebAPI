/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.Composite.ans2;

public abstract class Weapon {
	public abstract void fire();
}
