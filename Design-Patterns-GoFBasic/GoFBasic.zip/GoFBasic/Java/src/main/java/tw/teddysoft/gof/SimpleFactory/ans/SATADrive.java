/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.SimpleFactory.ans;

public class SATADrive extends Drive {

	public SATADrive(int index) {
		super(index);
	}
}
