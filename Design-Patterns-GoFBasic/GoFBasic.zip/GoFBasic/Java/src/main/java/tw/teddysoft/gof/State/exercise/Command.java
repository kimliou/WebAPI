package tw.teddysoft.gof.State.exercise;

public interface Command {
	CheckResult execute();
}
