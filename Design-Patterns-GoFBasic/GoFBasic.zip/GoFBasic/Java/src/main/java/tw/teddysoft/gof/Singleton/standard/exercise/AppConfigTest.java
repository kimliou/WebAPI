package tw.teddysoft.gof.Singleton.standard.exercise;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AppConfigTest {

// TODO: Uncomment the following code
//	@Test
//	public void default_instance_is_not_null() {
//		assertNotNull(AppConfig.getInstance());
//	}
//	@Test
//	public void call_getInstance_twice_gets_the_same_instance() {
//		assertEquals(AppConfig.getInstance(), AppConfig.getInstance());
//	}
//
//	@Test
//	public void cannot_call_the_default_constructor() throws Exception {
//		IllegalAccessException thrown = Assertions.assertThrows(IllegalAccessException.class, () -> {
//			String className = "tw.teddysoft.gof.Singleton.standard.exercise.AppConfig";
//			Class<?> c =  Class.forName(className);
//			c.newInstance();
//		});
//		assertTrue(thrown.getMessage().contains("cannot access a member of class"));
//	}
}

