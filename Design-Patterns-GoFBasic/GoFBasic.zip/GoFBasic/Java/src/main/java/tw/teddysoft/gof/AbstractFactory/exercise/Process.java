/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.AbstractFactory.exercise;

public abstract class Process {
	private int _id;
	
	public Process(int id) {
		_id = id;
	}
}
