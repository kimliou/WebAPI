/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.FactoryMethod.exercise;

public class USBDrive extends Drive {

	public USBDrive(int index) {
		super(index);
	}
}
