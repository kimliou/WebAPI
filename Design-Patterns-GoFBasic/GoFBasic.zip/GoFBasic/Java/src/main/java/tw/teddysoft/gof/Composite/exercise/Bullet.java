package tw.teddysoft.gof.Composite.exercise;

public abstract class Bullet {
	public abstract void fire();
}
