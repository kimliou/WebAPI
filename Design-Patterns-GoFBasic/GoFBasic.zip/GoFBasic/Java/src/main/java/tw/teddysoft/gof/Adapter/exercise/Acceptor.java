/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.Adapter.exercise;

public class Acceptor extends ConfigObject {
	public Acceptor() {
	}
}
