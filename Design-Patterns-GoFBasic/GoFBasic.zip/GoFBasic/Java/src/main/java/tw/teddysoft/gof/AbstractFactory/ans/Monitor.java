package tw.teddysoft.gof.AbstractFactory.ans;

public abstract class Monitor {
	private int id;
	public Monitor(int id) {
		this.id = id;
	}
}
