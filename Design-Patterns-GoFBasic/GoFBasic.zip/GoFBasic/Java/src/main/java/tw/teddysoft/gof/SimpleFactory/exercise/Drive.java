/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.SimpleFactory.exercise;

public class Drive {
	
	public Drive(int index){
	}
	
	public void updateFreeSpace() {
	}

	public void doQuickSMARTCheck() {
	}
}
