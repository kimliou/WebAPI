/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.AbstractFactory.exercise;

public class LinuxProcess extends Process {
	public LinuxProcess(int id){
		super(id);
	}
}
