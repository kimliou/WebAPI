/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.Observer.exercise;

public class Door {
	public Door(String ipAddress){
		
	}

	public String getDoorStatus(){
		// TODO: 傳回遠端門開啟或關閉，此類別實作由廠商提供
		return null;
	}
}
