package tw.teddysoft.gof.Facade.exercise;

public class Fax {
	
	public String send(int phoneNumber, Image image) {
		
		return "OK";
	}

}
