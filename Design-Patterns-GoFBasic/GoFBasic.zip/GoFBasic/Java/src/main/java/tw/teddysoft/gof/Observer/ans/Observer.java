/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.Observer.ans;

public interface Observer {
	void update(Subject subject);
}
