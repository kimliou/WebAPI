/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.Strategy.exercise;

public enum FileSystemEnum {
	NTFS, FAT32, FAT;
}
