package tw.teddysoft.gof.Facade.exercise;

public class ScannerException extends Exception {
	public ScannerException(String msg) {
		super(msg);
	}
}
