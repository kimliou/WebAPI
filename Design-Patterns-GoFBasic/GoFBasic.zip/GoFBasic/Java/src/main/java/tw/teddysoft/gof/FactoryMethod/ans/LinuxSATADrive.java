/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.FactoryMethod.ans;

public class LinuxSATADrive extends Drive {
	public LinuxSATADrive(int index) {
		super(index);
	}
}
