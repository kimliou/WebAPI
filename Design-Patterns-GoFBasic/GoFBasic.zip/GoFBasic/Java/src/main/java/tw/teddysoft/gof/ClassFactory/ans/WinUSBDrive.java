/*
 * Copyright 2016 TeddySoft Technology. All rights reserved.
 * 
 */
package tw.teddysoft.gof.ClassFactory.ans;

public class WinUSBDrive extends Drive {
	public WinUSBDrive(int index) {
		super(index);
	}
}
