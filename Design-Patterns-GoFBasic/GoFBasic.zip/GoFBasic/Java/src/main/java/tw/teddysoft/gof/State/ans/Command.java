package tw.teddysoft.gof.State.ans;

public interface Command {
	CheckResult execute();
}
