package tw.teddysoft.gof.ClassFactory.ans;

public class Platform {

	public static boolean isWindows() {
		return false;
	}

	public static boolean isLinux() {
		return true;
	}
	
}
