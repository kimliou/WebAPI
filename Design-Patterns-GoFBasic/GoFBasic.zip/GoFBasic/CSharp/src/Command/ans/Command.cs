﻿/*
 * Copyright 2017 TeddySoft Technology. 
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.Command.Ans
{
    public interface Command
	{
	    Result execute();
	}
}
