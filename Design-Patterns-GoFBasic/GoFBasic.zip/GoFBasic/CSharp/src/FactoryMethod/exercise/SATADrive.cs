﻿/*
 * Copyright 2017 TeddySoft Technology. 
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.FactoryMethod.Exercise
{
    public class SATADrive : Drive
	{
		public SATADrive(int imp) : base(imp)
		{
		}
    }
}
