﻿/*
 * Copyright 2017 TeddySoft Technology. 
 * 
 */
using System;
namespace Tw.Teddysoft.Gof.Adapter.Ans
{
    public class Acceptor : ConfigObject
    {
        public Acceptor()
        {
        }
    }
}
