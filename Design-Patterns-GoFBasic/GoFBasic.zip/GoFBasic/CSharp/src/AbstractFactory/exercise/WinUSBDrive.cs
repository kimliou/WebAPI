﻿/*
 * Copyright 2017 TeddySoft Technology.
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.AbstractFactory.Exercise
{
    public class WinUSBDrive : Drive
	{
    	public WinUSBDrive(int imp) : base(imp)
	    {
	    }
    }
}
