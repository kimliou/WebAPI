﻿/*
 * Copyright 2017 TeddySoft Technology.
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.AbstractFactory.Exercise
{
    class LinuxSATADrive : Drive
    {
		public LinuxSATADrive(int imp) : base(imp)
		{
		}
    }
}
