﻿/*
 * Copyright 2017 TeddySoft Technology.
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.AbstractFactory.Exercise
{
    public class Drive
    {
        public Drive(int index)
        {
        }
        public void updateFreeSpace()
        {
        }
        public void doQuickSMARTCheck()
        {
        }
    }
}
