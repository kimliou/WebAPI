﻿/*
 * Copyright 2017 TeddySoft Technology.
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.AbstractFactory.Exercise
{
    public class LinuxProcess : Process
	{
		public LinuxProcess(int id) : base(id) 
		{
		}
    }
}
