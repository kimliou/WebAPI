﻿/*
 * Copyright 2017 TeddySoft Technology.
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.AbstractFactory.Ans
{
    public class WinSATADrive : Drive
	{
	    public WinSATADrive(int imp) : base(imp)
	    {
    	}
    }
}
