﻿/*
 * Copyright 2017 TeddySoft Technology.
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.AbstractFactory.Ans
{
    public class LinuxUSBDrive : Drive
    {
        public LinuxUSBDrive(int imp) : base (imp)
        {
        }
    }
}
