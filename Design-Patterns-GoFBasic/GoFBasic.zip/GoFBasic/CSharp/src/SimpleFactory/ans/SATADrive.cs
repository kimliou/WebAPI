﻿/*
 * Copyright 2017 TeddySoft Technology. 
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.SimpleFactory.Ans
{
    public class SATADrive : Drive
	{
		public SATADrive(int imp) : base(imp)
		{
		}
    }
}
