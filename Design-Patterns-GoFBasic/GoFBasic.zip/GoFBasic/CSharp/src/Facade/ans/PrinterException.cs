﻿﻿/*
 * Copyright 2017 TeddySoft Technology. 
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.Facade.Ans
{
    public class PrinterException : Exception
	{
	    public PrinterException(String msg) : base(msg)
		{
		}
    }
}
