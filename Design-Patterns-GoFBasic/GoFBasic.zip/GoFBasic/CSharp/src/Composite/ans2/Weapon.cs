﻿/*
 * Copyright 2017 TeddySoft Technology. 
 *
 */
using System;

namespace Tw.Teddysoft.Gof.Composite.Ans2
{
    public abstract class Weapon
	{
		public abstract void fire();
	}
}
