﻿/*
 * Copyright 2017 TeddySoft Technology. 
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.Observer.Exercise
{
    public class Window
    {
		public Window(String ipAddress)
		{
		}

		public bool isBroken()
		{
			// TODO: 
			return false;
		}

		public bool isOpen()
		{
			// TODO: 
			return false;
		}
    }
}
