﻿/*
 * Copyright 2017 TeddySoft Technology. 
 * 
 */
using System;

namespace Tw.Teddysoft.Gof.Observer.Exercise
{
    public enum Status
    {
        PENDING, OK, WARRING, CRITICAL
    }
}
